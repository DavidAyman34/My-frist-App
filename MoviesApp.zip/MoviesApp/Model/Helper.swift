//
//  instantiateViewController.swift
//  MoviesApp
//
//  Created by Divo Ayman on 2/26/20.
//  Copyright © 2020 Divo Ayman. All rights reserved.
//

import Foundation
import UIKit
struct Cells {
    static let cell = "TableNib"
}
struct Instantiate {
    static let signupVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
    static let signinVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignInVC") as! SignInVC
    static let profileVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
    static let moviesVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MoviesListVC") as! MoviesListVC
    static let mapVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
        static let MoviesDetil = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MoviesDetil") as! MoviesDetil
}
struct VCs {
    static let signupVC = "SignUpVC"
    static let signinVC =  "SignInVC"
    static let profileVC = "ProfileVC"
    static let moviesVC = "MoviesListVC"
    static let mapVC = "MapViewController"
}
struct Storybords {
    static let main = "Main"
}
