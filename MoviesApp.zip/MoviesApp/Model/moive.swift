//
//  moive.swift
//  MoviesApp
//
//  Created by Divo Ayman on 3/3/20.
//  Copyright © 2020 Divo Ayman. All rights reserved.
//

import Foundation
struct movie {
    var name : String
    var desc : String
    var image : String
}
