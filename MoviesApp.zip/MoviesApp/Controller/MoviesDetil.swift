//
//  MoviesDetil.swift
//  MoviesApp
//
//  Created by Divo Ayman on 3/3/20.
//  Copyright © 2020 Divo Ayman. All rights reserved.
//

import UIKit

class MoviesDetil: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var movieImage: UIImageView!
    var detil : movie!
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = detil.name
        descLabel.text = detil.desc
        movieImage.image = UIImage(named: detil.image)
        // Do any additional setup after loading the view.
    }
    @IBAction func backBtn(_ sender: UIButton) {
       let movies = Instantiate.moviesVC
        self.present(movies, animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
