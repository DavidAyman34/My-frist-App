//
//  ProfileVC.swift
//  MoviesApp
//
//  Created by Divo Ayman on 2/25/20.
//  Copyright © 2020 Divo Ayman. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController {
var presentData = UserDefaultsManager.shared().getSavedData()
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
  
preview()   
        // Do any additional setup after loading the view.
    }
    func preview(){
        nameLabel.text = presentData.name
        emailLabel.text = presentData.email
        phoneLabel.text = presentData.phone
        genderLabel.text = presentData.gender.map { $0.rawValue }
        addressLabel.text = presentData.addres
        
    }
    @IBAction func logOutBtn(_ sender: UIButton) {
        presentData.isLogin = false
        UserDefaultsManager.shared().saveDataFor(user: presentData)
        let SignInVC = UIStoryboard.init(name: Storybords.main, bundle: nil).instantiateViewController(withIdentifier: VCs.signinVC) as! SignInVC
        self.present(SignInVC, animated: true, completion: nil)
    }
    @IBAction func backBtn(_ sender: UIBarButtonItem) {
        let moviesVC = UIStoryboard.init(name: Storybords.main, bundle: nil).instantiateViewController(withIdentifier:VCs.moviesVC) as! MoviesListVC
        self.present(moviesVC, animated: true, completion: nil)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
