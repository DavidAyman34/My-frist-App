//
//  MoviesListVC.swift
//  MoviesApp
//
//  Created by Divo Ayman on 2/25/20.
//  Copyright © 2020 Divo Ayman. All rights reserved.
//

import UIKit

class MoviesListVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableview: UITableView!
    var dataSaved = UserDefaultsManager.shared().getSavedData()
    var moviesName = [ "Hobes and Shaw","Glass", "Fast and Furious 7", "Transporter 3","Now you see me 2","Avengers endgame","The conjuring","The codfather","Insidious","Maleficent 2"]
    override func viewDidLoad() {
        super.viewDidLoad()
        dataSaved.isLogin = true
        UserDefaultsManager.shared().saveDataFor(user: dataSaved)
        tableview.dataSource = self
        tableview.delegate = self
        let tableNib = UINib(nibName: "TableViewCell", bundle: nil)
        tableview.register(tableNib, forCellReuseIdentifier: "TableNib")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return moviesName.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 210
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Instantiate.MoviesDetil.detil = movie(name: moviesName[indexPath.row], desc: "Details", image: moviesName[indexPath.row])
        self.present(Instantiate.MoviesDetil, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableNib", for: indexPath)  as! TableNib
        cell.movieNameLabel?.text = moviesName[indexPath.row]
        cell.movieImage.image = UIImage(named: moviesName[indexPath.row])
        cell.movieDesLabel.text = "Details Details Details Details Details Details Details"
        return cell
    }
    @IBAction func profileBtn(_ sender: UIBarButtonItem) {
        let profile = Instantiate.profileVC
        self.present(profile, animated: true, completion: nil)
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

