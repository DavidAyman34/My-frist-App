//
//  SignInVC.swift
//  MoviesApp
//
//  Created by Divo Ayman on 2/25/20.
//  Copyright © 2020 Divo Ayman. All rights reserved.
//

import UIKit

class SignInVC: UIViewController {
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    var user : User!
    var returnData = UserDefaultsManager.shared().getSavedData()
    override func viewDidLoad() {
        super.viewDidLoad()
        returnData.isLogin = false
        print(returnData.email)
        print(returnData.passWord)
      //  Defaults.saveDataFor(user: returnData)
        // Do any additional setup after loading the view.
    }
    func goToProfile (){
        let MoviesListVC = UIStoryboard.init(name: Storybords.main, bundle: nil).instantiateViewController(withIdentifier: VCs.moviesVC) as! MoviesListVC
        self.present(MoviesListVC, animated: true, completion: nil)
    }
    func checkData() {
        if emailTextField.text == returnData.email{
        if passwordTextField.text == returnData.passWord {
            goToProfile()
        }else{ let alert = UIAlertController(title: "Check Password", message: "please write Your password.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert, animated: true)}
        
        
        }else{ let alert = UIAlertController(title: "Check Email", message: "please write Your Email.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert, animated: true)}
            
        }
    
    @IBAction func signInBtn(_ sender: UIButton) {
    checkData()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
